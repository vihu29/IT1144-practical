document.querySelector("form").addEventListener("submit", function(event) {
        event.preventDefault();

        let name = document.getElementById("contact-name").value;
        let email = document.getElementById("email").value;
        let phone = document.getElementById("phone").value;
        let weddingDate = document.getElementById("wedding-date").value;
        let guests = document.getElementById("guests").value;
        let weddingType = document.getElementById("wedding-type").value;
        let addressField = document.getElementById("address");
        let address = addressField ? addressField.value : "Not Provided";
        let message = "🎉 Registration Details 🎉\n\n" +
                      "👤 Name: " + name + "\n" +
                      "📧 Email: " + email + "\n" +
                      "📞 Phone: " + phone + "\n" +
                      "📅 Date: " + weddingDate + "\n" +
                      "👥 Guests: " + guests + "\n" +
                      "💒 Type: " + weddingType + "\n" +
                      "📍 Address: " + address;
        alert(message);
    });
